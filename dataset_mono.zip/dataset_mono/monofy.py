from PIL import Image
import os 
import shutil
import glob 


def monofy(dir):
    image_file = Image.open(dir) # open colour image
    image_file = image_file.convert('1') # convert image to black and white
    image_file.save(dir)


x = glob.glob("/home/byun/aiproj/dataset_mono/VALIDATION_DIR/dnb/*.png")
print(x)

for files in x:
    monofy(files)